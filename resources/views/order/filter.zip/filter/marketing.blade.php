<div class="card card-xxl-stretch mb-5 mb-xl-8">
    <div class="card-header border-0 pt-5">
    	<h3 class="card-title align-items-start flex-column">
    		<span class="card-label fw-bolder fs-3 mb-1">Filter</span>
    	</h3>
    </div>
    <div class="card-body py-3">
    	<form action="">
    		<div class="row mb-3">
                <div class="col-md-3 fv-row">
                	 <input type="search"  name="search" id="search" class="form-control form-control-solid" placeholder="Serach By OrderCode or Title" >
                </div>
                           
    			<div class="col-lg-3 fv-row fv-plugins-icon-container">
    				<select name="uid"  id="filter"  id="" aria-label="Select a Timezone" data-control="select2" data-placeholder="Search By Name Email Mobile" class="form-select form-select-solid form-select-lg " data-select2-id="select2-data-16-7969" tabindex="-1" >
						<option value="" data-select2-id="select2-data-18-e9lh"></option>
    					@foreach($data['user'] as $user)
						<option value="{{$user->id}}">{{$user->name}} {{$user->email}}({{$user->mobile_no}})</option>
						@endforeach
    				</select>
    			<div class="fv-plugins-message-container invalid-feedback"></div></div>
    			    <div class="col-lg-3 fv-row fv-plugins-icon-container">
    				<select name="status" id="status" aria-label="Select a Language" data-control="select2" data-placeholder="Status" class="form-select form-select-solid form-select-lg " data-select2-id="select2-data-13-mh4q" tabindex="-1" >
    					<option value="" ></option>
                        
                           @foreach($data['Status'] as $Status)
                           <option value="{{$Status->status}}">{{$Status->status}}</option>
                           @endforeach
    				</select>
    				<div class="fv-plugins-message-container invalid-feedback"></div>
    			</div>
                <div class="col-lg-3 fv-row fv-plugins-icon-container">
                    <select name="writer" id="writer" aria-label="Select a Timezone" data-control="select2" data-placeholder="Search By writer Name " class="form-select form-select-solid form-select-lg " data-select2-id="select2-data-16-79699" tabindex="-1" >
    					<option value="" data-select2-id="select2-data-18-e9lhs"></option>
                        @foreach($data['Team'] as $writer)
                        <option value="{{$writer->writer_name}}">{{$writer->writer_name}}</option>
                        @endforeach
    				</select>
    			</div>

                <div class="col-md-3 fv-row">
                    <input type="date" name="from_date" id="from_date" class="form-control form-control-solid" placeholder="Search By OrderCode">
                </div>
                <div class="col-md-3 fv-row">
                    <input type="date" name="to_date" id="to_date" class="form-control form-control-solid" placeholder="Search By OrderCode">
                </div>

                <div class="col-lg-3 fv-row fv-plugins-icon-container">
                    <select name="date_status" id="date_status" aria-label="Select a Timezone" data-control="select2" data-placeholder="Search By writer Name " class="form-select form-select-solid form-select-lg select2-hidden-accessible" data-select2-id="select2-data-16-796922" tabindex="-1" aria-hidden="true">
                        <option value=""></option>
                        <option value="writer_deadline">Writer Deadline</option>
                        <option value="delivery_date">Delivery Date</option>
                    </select>
                </div>
    			</div>

                <div class="row mb-3 additional-filters" style="display:none;">
               
                <div class="col-lg-3 fv-row fv-plugins-icon-container">
                    <select name="college"  id="college" aria-label="Select a Timezone" data-control="select2" data-placeholder="Search By College Name" class="form-select form-select-solid form-select-lg" tabindex="-1">
                        <option value=""></option>
                        @foreach($data['college'] as $college)
                            <option value="{{$college->college_name}}">{{$college->college_name}}</option>
                        @endforeach  
                    </select>
                </div>
                
                <div class="col-lg-3 fv-row fv-plugins-icon-container">
                    <select name="extra" id="extra" aria-label="Select a Timezone" data-control="select2" data-placeholder="Search By Tech Resit Failed Job" class="form-select form-select-solid form-select-lg" tabindex="-1">
                        <option value=""></option>
                        <!-- Option for Tech -->
                        <option value="tech">Tech</option>
                        <!-- Option for Resit -->
                        <option value="resit">Resit</option>
                        <!-- Option for Failed Job -->
                        <option value="failedjob">Failed Job</option>
                    </select>
                </div>

                
                </div>
                


                
    			<div class="col-lg-12 fv-row fv-plugins-icon-container">
    				<button type='submit' class="btn btn-sm btn-primary" >Search</button>
                    <a href="#" id="resetFilters" class="btn btn-sm btn-danger">Reset</a>
                    <button type="button" id="showMoreFilters" class="btn btn-sm btn-success">Show More Filters</button>

    			</div>
    		</div>
    	</form>

		
    </div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        // Function to handle both search and filter
        function applyFilters() {
            var $search = $('#search').val(),
                $uid = $('#filter').val(),
                $status = $('#status').val(),
                $writer = $('#writer').val(),
                $dateStatus = $('#date_status').val(),
                $fromDate = $('#from_date').val(),
                $toDate = $('#to_date').val(),
                $WriterTL = $('#writerTL').val(),
                $SubWriter = $('#SubWriter').val(),
                $college = $('#college').val(),
                $extra = $('#extra').val();

                // alert($extra)

            if ($search || $uid || $status || $writer || $dateStatus || $fromDate || $toDate || $WriterTL || $SubWriter || $college || $extra) {
                $('.allData').hide();
                $('.searchData').show();
            } else {
                $('.allData').show();
                $('.searchData').hide();
            }

            $.ajax({
                type: 'get',
                url: '{{ url('search') }}',
                data: {
                    'search': $search,
                    'uid': $uid,
                    'status': $status,
                    'writer': $writer,
                    'date_status': $dateStatus,
                    'from_date': $fromDate,
                    'to_date': $toDate,
                    'WriterTL': $WriterTL,
                    'SubWriter': $SubWriter,
                    'college': $college,
                    'extra': $extra
                },
                success: function (data) {
                    console.log(data);
                    $('#content').html(data);
                },
                error: function (data) {
                    console.log('Error:', data);
                }
            });
        }

        // Show More button click event to reveal additional filters
        $('#showMoreFilters').on('click', function () {
            $('.additional-filters').toggle();
        });

        // Search button click event to trigger filter application
        $('#searchButton').on('click', applyFilters);

        // Search functionality
        $('#search').on('keyup', applyFilters);

        // Filter functionality
        $('#filter, #status, #writer, #date_status, #from_date, #to_date, #writerTL, #SubWriter, #college, #extra').on('change', applyFilters);
    });
</script>


<script>
    $('#resetFilters').on('click', function () {
        alert(resert)
    $('form')[0].reset();
    applyFilters(); // Call applyFilters to reset the data
});
</script>





	